<br>
       <div class="container">
        <div class="row">
   
        <div class="col-md-10 col-md-offset-1">
            <h2>Live Video Class</h2>

            <div class="tiny-border"></div>
            <div class="col-md-6">
              <form action="<?php echo base_url('Live/getLink')?>" method="POST">
                <div class="field-set">
                  <label>Put Your Video Link Here:</label>
                  <input type='text' name='link' id='link' class="form-control">
                </div>
                <div id='submit' class="pull-left">
                  <input type='submit' id='submit' value='Go Live' class="btn btn-custom color-2">
                </div>
              </form> 
           </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<hr>
