<br>
       <div class="container">
        <div class="row">
   
        <div class="col-md-10 col-md-offset-1">
            <h2>Live Video Class</h2>

            <div class="tiny-border"></div>
            <div class="col-md-6">

              <?php if($livelink != ""){ ?>

                <iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0"width="788.54" height="443" type="text/html" src="<?php echo $livelink; ?>"><div><small><a href="https://youtubeembedcode.com/en">https://youtubeembedcode.com/en</a></small></div><div><small><a href="https://promocode.com.ph/">https://promocode.com.ph/</a></small></div><div><small><a href="https://youtubeembedcode.com/en">https://youtubeembedcode.com/en</a></small></div><div><small><a href="https://promocode.com.ph/">http://promocode.com.ph/</a></small></div></iframe>

              <?php } ?> 
           </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<hr>
